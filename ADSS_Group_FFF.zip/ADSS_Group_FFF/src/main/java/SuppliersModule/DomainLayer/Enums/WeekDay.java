package SuppliersModule.DomainLayer.Enums;

public enum WeekDay {
    Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday
}
