package SuppliersModule.DomainLayer.Enums;

public enum DeliveringMethod {
    PICK_UP, SELF_DELIVERING
}
