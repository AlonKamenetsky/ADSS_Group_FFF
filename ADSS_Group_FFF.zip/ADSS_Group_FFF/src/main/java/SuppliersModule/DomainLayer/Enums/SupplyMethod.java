package SuppliersModule.DomainLayer.Enums;

public enum SupplyMethod {
    SCHEDULED, ON_DEMAND
}
