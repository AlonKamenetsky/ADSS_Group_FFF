package SuppliersModule.DomainLayer.Enums;

public enum PaymentMethod {
    CHECK, BANK_TRANSACTION, CASH
}
