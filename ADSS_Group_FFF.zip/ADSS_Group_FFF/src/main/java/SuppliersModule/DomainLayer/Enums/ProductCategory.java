package SuppliersModule.DomainLayer.Enums;

public enum ProductCategory {
    DAIRY, FROZEN, FRUITS_AND_VEGETABLES, DRINKS, MEATS, DRIED, MISCELLANEOUS
}
