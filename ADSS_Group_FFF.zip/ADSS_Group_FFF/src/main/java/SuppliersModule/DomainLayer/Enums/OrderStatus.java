package SuppliersModule.DomainLayer.Enums;

public enum OrderStatus {
    RECEIVED, IN_PROCESS, DELIVERED, ARRIVED, CANCELLED, PENDING
}
