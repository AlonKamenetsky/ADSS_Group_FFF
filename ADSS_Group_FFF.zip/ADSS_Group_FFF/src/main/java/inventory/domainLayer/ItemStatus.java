package inventory.domainLayer;


public enum ItemStatus {
    NORMAL,
    DAMAGED,
    EXPIRED
}